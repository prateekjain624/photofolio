import React, { useEffect, useState } from "react";
import back from "../Assets/back.png";
import search from "../Assets/search.png";
import edit from "../Assets/edit.png";
import DeleteImage from "../Assets/trash-bin.png";
import styles from "../ImageList/imageliststyles.module.css";
import ImageForm from "../ImageForm/ImageForm";

import { db } from "../../fireebaseinit";
import { addDoc, collection, onSnapshot, doc } from "firebase/firestore";

// main function
const Albumimages = ({ handleBack, albumId, title }) => {
  const [showForm, setShowForm] = useState(false);
  const [images, setImages] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(null);
  const [imageToUpdate, setImageToUpdate] = useState(null);

  const handleShowForm = () => {
    setShowForm((prevForm) => !prevForm);
  };

  const handleImageCreate = async (imagesDetails) => {
    try {
      await addDoc(collection(db, "images"), { albumId, ...imagesDetails });
      setShowForm(false);
    } catch (err) {
      console.log(err);
    }
  };

  const getImageData = () => {
    const unsub = onSnapshot(collection(db, "images"), (querySnapshot) => {
      const imageData = querySnapshot.docs
        .filter((doc) => doc.data().albumId === albumId)
        .map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
      setImages(imageData);
    });
  };

  useEffect(() => {
    getImageData();
  }, [albumId]);
  // console.log(images);

  // rendering UI
  return (
    <>
      {showForm ? (
        <ImageForm handleImageCreate={handleImageCreate} albumTitle={title} />
      ) : (
        ""
      )}
      <div className={styles.imagelistTop}>
        <span>
          <img
            src={back}
            alt="back"
            className={styles.back}
            onClick={handleBack}
          />
        </span>
        <h3>images in {title} albums</h3>
        <div className={styles.imagelistSearch}>
          <input type="text" />
          <img src={search} alt="search" />
        </div>
        <button
          onClick={handleShowForm}
          className={showForm ? styles.active : ""}
        >
          {showForm ? "Cancel" : "Add image"}
        </button>
      </div>
      {/* here i am displaying all the images of the album */}
      <div className={styles.imageList}>
        {images.map((image, index) => (
          <div
            className={styles.imageListImage}
            key={index}
            onMouseOver={() => setCurrentIndex(index)}
            onMouseLeave={() => setCurrentIndex(null)}
          >
            <div
              className={`${styles.update} ${
                currentIndex === index && styles.active
              }`}
            >
              <img src={edit} alt="" />
            </div>
            <div
              className={`${styles.delete} ${
                currentIndex === index && styles.active
              }`}
            >
              <img src={DeleteImage} alt="" />
            </div>
            <img src={image.imageUrl} alt="" />
            <span>{image.title}</span>
          </div>
        ))}
      </div>
    </>
  );
};

export default Albumimages;
