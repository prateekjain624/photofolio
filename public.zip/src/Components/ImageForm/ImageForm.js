import { useState } from "react";
import styles from "../ImageForm/ImageForm.module.css";

const ImageForm = ({ handleImageCreate, albumTitle }) => {
  const [title, setTitle] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const onSubmitHandler = (e) => {
    e.preventDefault();

    const imagesDetails = {
      title: title,
      imageUrl: imageUrl,
    };
    handleImageCreate(imagesDetails);
    clearInput();
  };

  const clearInput = () => {
    setTitle("");
    setImageUrl("");
  };

  return (
    <div className={styles.ImageForm}>
      <span>Add images to {albumTitle}</span>
      <form onSubmit={onSubmitHandler}>
        <input
          type="text"
          required
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          type="text"
          required
          placeholder="Image url"
          value={imageUrl}
          onChange={(e) => setImageUrl(e.target.value)}
        />
        <div className={styles.actions}>
          <button type="button" onClick={clearInput}>
            Clear
          </button>
          <button>Add</button>
        </div>
      </form>
    </div>
  );
};

export default ImageForm;
